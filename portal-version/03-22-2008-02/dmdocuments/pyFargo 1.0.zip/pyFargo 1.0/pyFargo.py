import os
import sys
from lib import decodeUnicode
import pprint
from lib import floatValue
import traceback
from lib import PickledHash
import globalVars
from lib import _utils
from lib import _psyco

_input_path = ['Z:/#zDisk/#IRS/2005/WellsFargo','Z:/#zDisk/#IRS/2006/WellsFargo','Z:/#zDisk/#IRS/2007/WellsFargo']
#_input_path = ['Z:/#zDisk/#IRS/2007/WellsFargo']

_deposits_symbol = 'Deposits'
_withdrawls_symbol = 'Withdrawals'

isProblemWithMoneyAnalysis = False
isProblemWithChecksAnalysis = False

def accountStatementParser(content,token):
    d = []
    d.append(token)
    for l in content:
	if (l.find(token) > -1):
	    d.append(l)
	    d.append(content[len(d)-1])
	    break
    return d

def accountDataParser(content,token,isUnique=True):
    d = []
    d.append(token)
    for l in content:
	if (l.find(token) > -1):
	    d.append([t.split() for t in l.split(':')])
	    if (isUnique):
		break
    return d

def accountDataBetweenParser(content,token1,token2):
    d = []
    d.append([token1,token2])
    isCollecting = False
    method = 1
    while ( (len(d) == 1) and (method <= 2) ):
	for l in content:
	    if (method == 1):
		if ( (not isCollecting) and (l.lower() == token1.lower()) ):
		    isCollecting = True
	    elif (method == 2):
		if ( (not isCollecting) and (l.lower().find(token1.lower()) > -1) ):
		    isCollecting = True
	    if (isCollecting):
		d.append([t.split() for t in l.split(':')])
		if (len(d[-1]) == 2):
		    dd = d[-1]
		    if ( (isTokenDateMMYY(dd[0][0])) and (isTokenDollarAmount(dd[1][-1])) ):
			for tok in d[-1][-1]:
			    d[-1][0].append(tok)
			del d[-1][-1]
	    isDoneCollecting = False
	    if (isCollecting):
		_token2 = list(token2) if not isinstance(token2,str) else [token2]
		for s in _token2:
		    if (l.find(s) > -1):
			isDoneCollecting = True
			break
	    if ( (isCollecting) and (isDoneCollecting) ):
		isCollecting = False
		break
	method += 1
    _d = []
    for i in xrange(len(d)-1,0,-1):
	dl = d[i]
	if ( (len(dl) == 1) and (dl[0][0] == token1) ):
	    _d.append(dl)
	    _d.reverse()
	    d = _d
	    break
	else:
	    _d.append(dl)
    return d

def isTokenDateMMYY(token):
    toks = token.split('/')
    return ( (len(toks) == 2) and (toks[0].isdigit()) and (toks[-1].isdigit()) )

def isTokenDollarAmount(token):
    toks = token.replace('$','').replace(',','').split('.')
    return ( (len(toks) == 2) and (toks[0].isdigit()) and (toks[-1].isdigit()) )

def depositsListAnalysis(content):
    d = []
    skip = []
    for i in xrange(0,len(content)-1):
	if (i in skip):
	    skip = skip[1:]
	    continue
	c = content[i]
	if (isTokenDateMMYY(c[0][0])):
	    d.append(c[0])
	    hasDollarAmount = False
	    while (not hasDollarAmount):
		if (isTokenDollarAmount(c[0][-1])):
		    hasDollarAmount = True
		else:
		    i += 1
		    skip.append(i)
		    c = content[i]
		    for cc in c[0]:
			d[-1].append(cc)
    return d

def depositsListReplacement(content,newList):
    for iBegin in xrange(1,len(content)-1):
	if (len(content[iBegin][0]) == 1):
	    break
    for iEnd in xrange(len(content)-1,iBegin,-1):
	if (len(content[iEnd][0]) == 1):
	    break
    cBegin = content[0:iBegin-1]
    cEnd = content[iEnd+1:]
    content = []
    for c in cBegin:
	content.append(c)
    for c in newList:
	content.append(c)
    for c in cEnd:
	content.append(c)
    return content

def withdrawlsListAnalysis(content):
    d = []
    skip = []
    for i in xrange(0,len(content)-1):
	if (i in skip):
	    skip = skip[1:]
	    continue
	c = content[i]
	if (isTokenDateMMYY(c[0][0])):
	    d.append(c[0])
	    hasDollarAmount = False
	    while (not hasDollarAmount):
		if (isTokenDollarAmount(c[0][-1])):
		    hasDollarAmount = True
		else:
		    i += 1
		    skip.append(i)
		    c = content[i]
		    for cc in c[0]:
			d[-1].append(cc)
    return d

def withdrawlsListReplacement(content,newList):
    for iBegin in xrange(1,len(content)-1):
	if (len(content[iBegin][0]) == 1):
	    break
    for iEnd in xrange(len(content)-1,iBegin,-1):
	if (len(content[iEnd][0]) == 1):
	    break
    content[iBegin:iEnd] = newList
    return content

def withdrawlsChecksAnalysis(content,token1):
    d = []
    isCollecting = False
    isNeedingValue = False
    for l in content:
	if (not isCollecting):
	    tag = l[0]
	    while (not isinstance(tag,str)):
		tag = tag[0]
	    if (tag.find(token1) > -1):
		isCollecting = True
		continue
	if (isCollecting):
	    tag = [t.replace('*','').replace(',','') for t in l[0]]
	    while ( (len(tag) > 2) and (tag[0].isdigit()) and (isTokenDateMMYY(tag[1])) and (isTokenDollarAmount(tag[2])) ):
		d.append(tag[0:3])
		del tag[:3]
		isNeedingValue = True
	    _tag = ' '.join(tag)
	    _tag = _tag.lower()
	    if ( (len(_tag) > 0) and (isNeedingValue) and ( (_tag.find('total checks') > -1) or (_tag.find('other withdrawals') > -1) or (isTokenDollarAmount(tag[-1])) ) ):
		if ( (isTokenDollarAmount(tag[-1])) or (_tag.find('other withdrawals') > -1) ):
		    d.append(l[0])
		    isCollecting = False
		    break
    return d

def moneyValuesAnalysis(content,total_value):
    global isProblemWithMoneyAnalysis
    isProblemWithMoneyAnalysis = False
    transactions = []
    try:
	tag = content[0]
	while (not isinstance(tag,str)):
	    tag = tag[0]
	isAdding = (tag.lower().find(_deposits_symbol.lower()) > -1)
	isSubtracting = (tag.find(_withdrawls_symbol) > -1)
	if ( (not isAdding) and (not isSubtracting) ):
	    print '(moneyValuesAnalysis) :: Invalid Money Analysis Data.'
	    return
	_total = floatValue.floatAsDollars(0.0)
	num = 0
	for l in content:
	    toks = l
	    if (isinstance(toks[0],str)):
		if ( ( (isTokenDateMMYY(toks[0])) or ( (len(toks) == 3) and (isTokenDateMMYY(toks[1])) ) ) and (isTokenDollarAmount(toks[-1])) ):
		    val = floatValue.floatValue(toks[-1],floatValue.Options.asDollar)
		    if (isAdding):
			_total += val
			num += 1
		    else:
			_total -= val
			num += 1
		    transactions.append([toks[0],' '.join(toks[1:-1]),toks[-1]])
	if ( (_total != total_value) and (abs(_total) != abs(total_value)) ):
	    isProblemWithMoneyAnalysis = True
	    print '(moneyValuesAnalysis) :: Invalid Money Analysis Data because the totals do not match.'
	    print '\t _total=(%s) [%s]' % (_total,str(_total.__class__))
	    print '\t total_value=(%s) [%s]' % (total_value,str(total_value.__class__))
	    print '\t num=(%s)' % (num)
	else:
	    print '(moneyValuesAnalysis) :: Values match.'
    except Exception, details:
	_traceback = traceback.format_exc()
	print '(moneyValuesAnalysis).ERROR :: Reason is "%s".\n%s' % (str(details),_traceback)
    return transactions

def valueOfChecks(content):
    global isProblemWithChecksAnalysis
    isProblemWithChecksAnalysis = False
    _total = floatValue.floatAsDollars(0.0)
    _totalValue = floatValue.floatAsDollars(0.0)
    if (isinstance(content,list)):
	for l in content:
	    toks = l
	    if (isinstance(toks[0],str)):
		if ( (len(toks) > 1) and (isTokenDateMMYY(toks[1])) and (isTokenDollarAmount(toks[-1])) ):
		    val = floatValue.floatValue(toks[-1],floatValue.Options.asDollar)
		    _total += val
		else:
		    val = floatValue.floatValue(toks[-1],floatValue.Options.asDollar)
		    _totalValue += val
	if (_total != _totalValue):
	    isProblemWithChecksAnalysis = True
	    print '(valueOfChecks) :: Invalid Checks Analysis Data because the totals do not match.'
	    print '\t _total=(%s) [%s]' % (_total,str(_total.__class__))
	    print '\t _totalValue=(%s) [%s]' % (_totalValue,str(_totalValue.__class__))
	else:
	    print '(valueOfChecks) :: Check Values match.'
    return _total

def persistTransactions(filename,transactions):
    if (isinstance(filename,str)):
	if (isinstance(transactions,list)):
	    dbx = PickledHash.PickledHash(filename)
	    for t in transactions:
		if (isTokenDollarAmount(t[-1])):
		    t[1] = t[1].replace(',','')
		    t[-1] = '%10.2f' % floatValue.floatValue(t[2],floatValue.Options.asFloat)
		    t[-1] = t[-1].strip()
		dbx['%d' % len(dbx)] = t
	    dbx.close()
	else:
	    print '(persistTransactions) :: WARNING - Invalid type for transactions which is of type "%s" but was supposed to be of type "list".' % (type(transactions))
    else:
	print '(persistTransactions) :: WARNING - Invalid type for filename which is of type "%s" but was supposed to be of type "str".' % (type(filename))

def main(fpath):
    if (not os.path.exists(globalVars.data_folder_symbol)):
	os.mkdir(globalVars.data_folder_symbol)
    pp = pprint.PrettyPrinter(indent=4)
    files = [f for f in os.listdir(fpath) if f.find('.txt') > -1]
    files.sort()
    print '(main) :: files=(%s)' % str(files)
    for f in files:
	content = [l.strip() for l in open(os.sep.join([fpath,f]), 'r').readlines()]
	content = [l for l in content if len(l) > 0]
	print '(main) :: f=(%s)' % f
	d_accountStatement = accountStatementParser(content,'Account Statement')
	statement_tag = d_accountStatement[-1]
	fileName = '.'.join(['_'.join(f.replace(',','').split()),'db'])
	print 'fileName=(%s)' % fileName
	toks = fileName.split('.')
	deposits_fileName = os.sep.join([globalVars.data_folder_symbol,'.'.join([toks[0]+'_deposits',toks[-1]])])
	print 'deposits_fileName=(%s)' % deposits_fileName
	withdrawls_fileName = os.sep.join([globalVars.data_folder_symbol,'.'.join([toks[0]+'_withdrawls',toks[-1]])])
	print 'withdrawls_fileName=(%s)' % withdrawls_fileName
	d_accountNumber = accountDataParser(content,'Account Number:')
	d_balanceOn = accountDataParser(content,'Balance on', False)
	d_deposits = accountDataParser(content,'Deposits')
	d_deposits[1] = d_deposits[1][0]
	value_deposits = floatValue.floatValue(d_deposits[1][1],floatValue.Options.asDollar)
	d_withdrawls = accountDataParser(content,'Withdrawals')
	d_withdrawls[1] = d_withdrawls[1][0]
	if ( (not isTokenDollarAmount(d_withdrawls[1][1])) and (len(d_withdrawls[1]) > 2) ):
	    d_withdrawls[1][1] = ''.join(d_withdrawls[1][1:])
	    del d_withdrawls[1][-1]
	value_withdrawls = floatValue.floatValue(d_withdrawls[1][1],floatValue.Options.asDollar)
	d_depositsList = accountDataBetweenParser(content,'Deposits','Total deposits')
	d_depositsList[0] = d_depositsList[0][0]
	d_withdrawlsList = accountDataBetweenParser(content,'Total deposits',['Total withdrawals','Total other withdrawals'])
	print
	print '='*80
	print
	print '='*80
	print 'd_accountStatement:'
	pp.pprint(d_accountStatement)
	print '-'*80
	print 'd_accountNumber:'
	pp.pprint(d_accountNumber)
	print '-'*80
	print 'd_balanceOn:'
	pp.pprint(d_balanceOn)
	print '-'*80
	print 'd_deposits:'
	pp.pprint(d_deposits)
	print '-'*80
	print 'd_withdrawls:'
	pp.pprint(d_withdrawls)
	print '-'*80
	print 'd_depositsList: %6.2f' % value_deposits
	d_depositsList = depositsListReplacement(d_depositsList,depositsListAnalysis(d_depositsList))
	transactions_deposits = moneyValuesAnalysis(d_depositsList,value_deposits)
	if (isProblemWithMoneyAnalysis):
	    pp.pprint(transactions_deposits)
	persistTransactions(deposits_fileName,transactions_deposits)
	print '-'*80
	print 'd_withdrawlsList: %6.2f' % value_withdrawls
	# Gather checks from d_withdrawlsList - lines between 'Checks' and 'Total Checks'
	d_withdrawlsChecks = withdrawlsChecksAnalysis(d_withdrawlsList,'Checks')
	d_withdrawlsList = withdrawlsListReplacement(d_withdrawlsList,withdrawlsListAnalysis(d_withdrawlsList))
	val_chks = valueOfChecks(d_withdrawlsChecks)
	value_withdrawls += val_chks
	transactions_withdrawls = moneyValuesAnalysis(d_withdrawlsList,value_withdrawls)
	print 'len(transactions_withdrawls)=(%s)' % len(transactions_withdrawls)
	chks = d_withdrawlsChecks[0:-1]
	if (len(chks) > 0):
	    chks.reverse()
	    for chk in chks:
		transactions_withdrawls.insert(0,chk)
	if (isProblemWithMoneyAnalysis):
	    pp.pprint(d_withdrawlsChecks)
	    print '*'*80
	    pp.pprint(transactions_withdrawls)
	persistTransactions(withdrawls_fileName,transactions_withdrawls)
	
	print
	print '='*80
	print
	print '='*80

if (__name__ == '__main__'):
    if (_utils.getVersionNumber() >= 251):
	_psyco.importPsycoIfPossible()
	if (isinstance(_input_path,str)):
	    main(_input_path)
	elif (isinstance(_input_path,list)):
	    for f in _input_path:
		main(f)
	else:
	    print 'Invalid _input_path of type "%s".' % str(_input_path.__class__)
    else:
	print 'You seem to be using the wrong version of Python, try using 2.5.1 rather than "%s".' % sys.version.split()[0]

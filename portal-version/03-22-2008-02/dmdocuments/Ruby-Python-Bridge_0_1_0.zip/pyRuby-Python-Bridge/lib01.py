#!/usr/bin/env python

def func(x):
    return(x+1)


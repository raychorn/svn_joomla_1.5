pyRuby-Python-Bridge - Provides a bridge between Ruby and Python.

pyRuby-Python-Bridge exists to allow Ruby developers to use Python to make their Ruby code run faster.

While working at BigFix I was faced with some Ruby-maniacs who wanted to use Ruby for absolutely every single programming task they felt the need to write code for.

Look, I am all for being enthusastic about my fav programming language(s) but can we get real for a moment ?!?

No matter how you want to slice it, the Ruby Language still runs about 1% to 5% the speed of compiled C++. (Check-out the published benchmarks.)

Heck, the Ruby Language runs easily 20x slower than optimized Python (when I say "optimized" Python I mean, use Psyco and learn how to code List Comprehensions).

Anyway, I felt the need to whip-up a nice little easy to deploy solution for those Ruby-maniacs at BigFix and here it is.

pyRuby-Python-Bridge !

A little TCP/IP magic and you too can deploy both Ruby and Python and use them together.

Maybe after doing a little Python programming you might begin to see how quickly and easily Python code comes rolling off your fingers and you might even begin writing Python more than Ruby - well, let's take this one step at a time and not get too far ahead of ourselves.

What ever happened to the Ruby-maniacs at BigFix ?!?

Well let's just say after they wasted 18 man-weeks on coding an ETL Process with the Ruby language they chose to recode that effort with Perl of all things and then they felt all smug and happy with themselves.

Perl ?!?  Really ?!?

If ever there was a language with weak data manipulation abilities Perl is it !

Perl has exactly one iterator operators, if you want to call it an "iterator" -- foreach.  Perl knows how to iterate over an array and that is it.

Going from Ruby to Perl is just weak, guys.

I can see going from Ruby to Python but Ruby to Perl ?!?  Weak !  Just weak !

Let's keep in mind these same Ruby-maniacs told me point-blank they would just make their Ruby code run faster by coding some Ruby extensions in C++. So "ha", we say, "ha" !

Okay, I thought to myself.  Let's just see if that ever happens.

But when push came to shove and it came time to make their Ruby code run faster those very same Ruby-maniacs at BigFix chose to run to Perl rather than spend all that development time coding Ruby extensions in C++.  Not like they would ever have that much time to code Ruby extensions in C++ just to make Ruby run faster.  But imagine having to code Ruby extensions just to make Ruby run faster in real terms.  "Boring !"

Perl !?!  Geez.  How desperate do you have to be to code Perl anyway ?!?  

(Your job is on the line, you just wasted 18 man-weeks on Ruby, your boss just told you to get your act together and you turn to Perl ?!?)

Well this is what happens when you can't stand using Microsoft development tools and you couldn't get the hang of having to use tabs to make your Python code readable let alone runnable and you don't use IDE tools that take care of your Python-tabs for you.

I will say, Perl was the safe bet at BigFix seeing how BigFix makes heavy use of Perl for their BES Product(s).  Of course nobody is gonna complain about BES being all that powerful seeing how it is powered by Perl.

It seems the folks at BigFix looked at Python but then decided they couldn't figure-out how to integrate Python into their BES Platform.

What ?

Python is so easy to integrate into anything that knows how to mount a DLL.  

The programmers at BigFix couldn't figure-out how to get the Python DLL to work from their C++ code ?  I bet they just didn't want to throw away all their Perl code.

Enjoy pyRuby-Python-Bridge !


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

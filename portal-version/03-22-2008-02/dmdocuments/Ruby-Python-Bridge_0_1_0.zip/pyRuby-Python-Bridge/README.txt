Installation:

* Step 1

Install Ruby 1.8.6

* Step 2

Install Python 2.5.1 or later.

* Step 3

Install Ruby-Python-Bridge

Create an empty folder.

Unzip the ZIP file into the empty folder.

Edit the pythonProcess.py file to customize your Python Process (Server).

Edit the rubyProcess.rb file to customize your Ruby Process (Client).

Open a DOS Box and run the pythonProcess.py

Open a DOS Box and run the rubyProcess.rb

Watch the Ruby Process dispatch code to Python for execution.

Watch the Python Process execute the Python code from Ruby.

Watch the Python Process exit upon receipt of the shutdown command.

Enjoy the power your Ruby code will now have access to once you too can leverage the power of Python from Ruby.

No source is provided for the Python code however you are free to use the Ruby Code in accordance with the terms of the License Agreement that applies to this offering.

You may not use this code for any commercial purpose without explicit written permission from the author of this work - this supercedes any other agreement or arrangment underwhich this code may have been obtained or licensed.

Copyright 2007, Hierarchical Applications Limited, Inc., All Rights Reserved.

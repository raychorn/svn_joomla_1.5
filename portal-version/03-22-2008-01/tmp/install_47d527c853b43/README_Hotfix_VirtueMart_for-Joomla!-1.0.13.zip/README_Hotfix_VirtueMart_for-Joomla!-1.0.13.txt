********************************
VirtueMart Hotfix
for Joomla! users who want to update to
Joomla! Version 1.0.13
********************************

Problem: Joomla! 1.0.13 was released as a "maintenance" release breaking backwards compatibility.
  * It uses a different method to encrypt passwords that the Joomla! version before
  * the core login functionality was changed
  
  In consequence VirtueMart won't be able to log customers in as long as you don't have applied this hotfix.
  
Solution:
  * Apply this hotfix


Installation
----------------

                                        My VirtueMart Version
                                                |
                   ----------------------------   ------------------------------
                  |                                                             |
                = 1.0.12                                                   < 1.0.12
  If you have installed the latest version                        If you have an older version of VirtueMart
  of VirtueMart (1.0.12) you can just overwrite                   (which probably is vulnerable then, because VirtueMart 1.0.11 fixed serious security issues!)
  the existing files of your VirtueMart installation with         you can just manually apply the fixes by 
  the ones from this HotFix Pacakage (the directory               changing the affected files by hand.
  structure is the same as in your installation)                                |
  Then you're done!                                                             |
  --------------------------------------                                        |
                                                                                |
                                                                                |
                                                                                |
                                                                                |
Changes to enable VirtueMart' Login        <------------------------------------
Functionality on Joomla! 1.0.13
-------------------------------------

*******************************************************************
File: /administrator/components/com_virtuemart/classes/ps_session.php
*******************************************************************
    Find line 174:
      ###
      172					} else {
      173						$userinfo = $_COOKIE['usercookie']['password']."|".$_COOKIE['usercookie']['username'];
      174					}
      ###

    and insert after:

      ###
                $remCookieValue = '';
                if( is_callable( array($mainframe, 'remCookieName_User'))) {
                  if( !empty( $GLOBALS['real_mosConfig_live_site'] ) && empty( $_REQUEST['real_mosConfig_live_site'])) {
                    $GLOBALS['mosConfig_live_site'] = $GLOBALS['real_mosConfig_live_site'];
                  }
                  $remCookieValue = mosGetParam( $_COOKIE, mosMainFrame::remCookieName_User(), '' );
                  
                }
      ###


    Find the comment in line 232:

        ###
        // Log the user in with his username
        ###

    and replace the section that follows until this line:

        ###
        require_once( ADMINPATH.'install.copy.php');
        ###

    with the following content:

        ###
              if( !empty( $usercookie["username"]) && !empty( $usercookie["password"] )) {
                if( defined('_JEXEC') ) {
                  //TODO
                }
                elseif( class_exists('mambocore')) {
                  //TODO
                }
                elseif( $GLOBALS['_VERSION']->RELEASE == '1.0' && (int)$GLOBALS['_VERSION']->DEV_LEVEL >= 13) {
                  // Joomla! >= 1.0.13 can be cheated to log in a user who has previsously logged in and checked the "Remember me" box
                  setcookie( mosmainframe::remCookieName_User(), $remCookieValue, false, '/' );
                  // there's no need to call "$mainframe->login"
                } else {
                  $mainframe->login($usercookie['username'], $usercookie['password'] );
                }
              }
        ###

*******************************************************************
File: /administrator/components/com_virtuemart/classes/ps_shopper.php
*******************************************************************
  Replace line 276:
    ###
    if( defined('_JEXEC') || class_exists('mambocore') ) {
    ###
    
  with this line:
    
    ###
    if( defined('_JEXEC') || class_exists('mambocore') || ( $GLOBALS['_VERSION']->RELEASE == '1.0' && (int)$GLOBALS['_VERSION']->DEV_LEVEL >= 13) ) {
    ###
    
  Complete Section:
    ###
      if( defined('_JEXEC') || class_exists('mambocore') || ( $GLOBALS['_VERSION']->RELEASE == '1.0' && (int)$GLOBALS['_VERSION']->DEV_LEVEL >= 13) ) {
				$mainframe->login($d['username'], $d['password'] );
			} else {
				$mainframe->login($d['username'], md5( $d['password'] ));
			}
    ###

*******************************************************************
File: /components/com_virtuemart/virtuemart_parser.php
*******************************************************************
  After lines 49/50:
      ###
          // This is necessary to get the real GID
          $my->load( $my->id );
      ###
      
  Insert the following line:

      ###
      $user = $my;
      ###

  Complete Snippet:

      ###
        if( $my->id > 0 ) {
          // This is necessary to get the real GID
          $my->load( $my->id );
          $user = $my;
        }
      ###

That's it.
Let's hope that the Joomla! maintenance team won't release another "maintenance" version like this!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Please!

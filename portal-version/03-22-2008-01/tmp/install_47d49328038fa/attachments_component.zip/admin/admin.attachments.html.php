<?php 
defined( '_JEXEC' ) or die( 'Restricted access' ); 
/**
* Attachments component
* @package Attachments
* @Copyright (C) 2007, 2008 Jonathan M. Cameron, All Rights Reserved
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @link http://joomlacode.org/gf/project/attachments/frs/
* @author Jonathan M. Cameron
**/

class HTML_attachments 
{
    function showAttachments( $option, &$rows, &$pageNav ) 
    { 
        global $mainframe;

        // Get the component parameters
        jimport('joomla.application.component.helper');
        $params = JComponentHelper::getParams('com_attachments');

        $secure = $params->get('secure',false);
        $icon_dir = $mainframe->getSiteURL() . 'components/com_attachments/media/icons/';

        ?>
        <form action="index.php" method="post" name="adminForm"> 
        <table class="adminlist"> 
        <thead> 
          <tr> 
            <th class="at_published" width="20"> 
              <input type="checkbox" name="toggle" value="" 
                     onclick="checkAll(<?php echo count( $rows ); ?>);" /> 
            </th>
            <th class="at_published" width="5%" nowrap="nowrap"><?php echo JText::_('PUBLISHED'); ?></th> 
            <th class="at_filename"><?php echo JText::_('ATTACHMENT FILENAME'); ?></th>
            <th class="at_description"><?php echo JText::_('DESCRIPTION'); ?></th>
            <th class="at_file_type"><?php echo JText::_('FILE TYPE'); ?></th> 
            <th class="at_file_size"><?php echo JText::_('FILE SIZE'); ?></th> 
          </tr> 
        </thead> 
        <?php
        // jimport('joomla.filter.output');   // Probably not needed on most systems
        $k = 0;
        $last_article_id = -1;
        for ($i=0, $n=count( $rows ); $i < $n; $i++) { 
            $row = &$rows[$i]; 
            $url = $mainframe->getSiteURL() . $row->url;
            if ( $secure ) {
                $url = "index.php?option=com_attachments&task=download&id=" . $row->id;
                $url = JRoute::_($url);
                }
            else
                $url = $mainframe->getSiteURL() . $row->url;
            $checked = JHTML::_('grid.id', $i, $row->id ); 
            $published = JHTML::_('grid.published', $row, $i );
            $size = intval($row->file_size / 1024);
            $link = JFilterOutput::ampReplace( 'index.php?option=' . $option . '&task=edit&cid[]='. $row->id );
            $artLink = JFilterOutput::ampReplace( '../index.php?option=com_content&view=article&id=' . $row->article_id );
            $view_article_title = JText::_('VIEW ARTICLE TITLE');
            if ( strlen($row->icon_filename) > 0 )
                $icon_url = $icon_dir . $row->icon_filename;
            else
                $icon_url = $icon_dir . 'generic.gif';
            $add_attachment_icon = $mainframe->getSiteURL() . 'components/com_attachments/media/attachment.gif';
            $add_attachment_title = JText::_('ADD ATTACHMENT TITLE');
            $edit_attachment_title = JText::_('EDIT THIS ATTACHMENT TITLE');
            $access_attachment_title = JText::_('ACCESS THIS ATTACHMENT TITLE');
            if ($row->article_id != $last_article_id) {
                $addAttachLink = 'index.php?option=' . $option . '&task=add&article_id='. $row->article_id;
                $addAttachLink = JFilterOutput::ampReplace($addAttachLink);
                $artLine = "<tr><td class=\"at_articlesep\" colspan=\"6\">";
                $artLine .= "<b>".JText::_('ARTICLE')." </b><a title=\"$view_article_title\" href=\"$artLink\">" . $row->title . "</a>";
                $artLine .= JFilterOutput::ampReplace('&nbsp;&nbsp;&nbsp;&nbsp;');
                $artLine .= "<a class=\"addAttach\" href=\"$addAttachLink\" title=\"$add_attachment_title\"><img src=\"$add_attachment_icon\" /></a>&nbsp;";
                $artLine .= "<a class=\"addAttach\" href=\"$addAttachLink\" title=\"$add_attachment_title\">".JText::_('ADD ATTACHMENT')."</a>";
                $artLine .= "</td></tr>\n";
                echo $artLine;
                $k = 0;
                }
            $last_article_id = $row->article_id;
          ?>
              <tr class="<?php echo "row$k"; ?>"> 
                <td><?php echo $checked; ?></td> 
                <td class="at_published" align="center"><?php echo $published;?></td> 
                <td class="at_filename">
                   <a href="<?php echo $link; ?>" title="<?php echo $edit_attachment_title; ?>"
                       ><img src="<?php echo $icon_url; ?>" /></a>&nbsp;<a 
                       href="<?php echo $link; ?>" title="<?php echo $edit_attachment_title; ?>"
                       ><?php echo $row->filename; ?></a> &nbsp;&nbsp;
                    <a class="downloadAttach" href="<?php echo $url; ?>" 
                       title="<?php echo $access_attachment_title; ?>"><?php echo JText::_('DOWNLOAD'); 
                    ?></a><a class="downloadAttach" href="<?php echo $url; ?>" 
                       title="<?php echo $access_attachment_title; ?>"><img src="<?php echo $icon_dir . 'download.gif'; ?>" /></a>
                </td> 
                <td class="at_description"><?php echo $row->description; ?></td>
                <td class="at_file_type"><?php echo $row->file_type; ?></td>
                <td class="at_file_size"><?php echo $size; ?></td>
              </tr> 
              <?php 
              $k = 1 - $k; 
            }
        ?>
        <tfoot>
         <tr>
         <td colspan="7"><?php echo $pageNav->getListFooter(); ?></td>
         </tr> 
        </tfoot>
      </table> 
      <input type="hidden" name="option" value="<?php echo $option;?>" /> 
      <input type="hidden" name="task" value="" /> 
      <input type="hidden" name="boxchecked" value="0" />
      </form>       
        <?php
    }

    function editAttachment( $row, $lists, $option, $change_article = False )
    {
        ?>
        <form action="index.php" method="post" name="adminForm" id="adminForm"> 
        <fieldset class="adminform"> 
        <legend><?php echo JText::_('DETAILS'); ?></legend> 
        <table class="admintable"> 
          <tr>
               <?php if ( $change_article ): ?>
                    <td class="key"><label for="article_id"><?php echo JText::_('SELECT ARTICLE'); ?></label></td>
                    <td><?php echo $lists['articles']; ?><input type="hidden" name="old_article_id" value="<?php echo $row->article_id; ?>" /></td>
                <?php else: ?>
                    <td class="key"><?php echo JText::_('ATTACHED TO ARTICLE'); ?></td>
                    <td><?php echo $row->article_title; ?>
                    <a class="changeArticle" href="index.php?option=com_attachments&amp;task=edit&amp;cid[]=<?php
                         echo $row->id; ?>&amp;change=article"><?php echo JText::_('CHANGE ARTICLE') ?></a>
                    </td>
                <?php endif; ?>
          </tr>
          <tr><td class="key"><?php echo JText::_('FILENAME'); ?></td>
              <td><?php echo $row->filename; ?></td>
          </tr>
          <tr><td class="key"><?php echo JText::_('SYSTEM FILENAME'); ?></td>
              <td><?php echo $row->filename_sys; ?></td>
          </tr>
          <tr><td class="key"><label for="display_filename"
                                     title="<?php echo JText::_('DISPLAY FILENAME TOOLTIP'); ?>"
                                     ><?php echo JText::_('DISPLAY FILENAME COLON'); ?></label></td>
              <td><input class="text" type="text" name="display_filename" 
                         id="display_filename" size="80" maxlength="80" 
                         title="<?php echo JText::_('DISPLAY FILENAME TOOLTIP'); ?>"
                         value="<?php echo $row->display_filename;?>" /><?php echo JText::_('(OPTIONAL)'); ?></td>
          </tr>
          <tr><td class="key"><label for="description"><?php echo JText::_('DESCRIPTION COLON'); ?></label></td>
              <td><input class="text" type="text" name="description" 
                 id="description" size="80" maxlength="255" 
                 value="<?php echo $row->description;?>" /></td>
          </tr>
          <tr><td class="key"><?php echo JText::_('UPLOADER NAME'); ?></td>
              <td><?php echo $row->uploader_name;?></td>
          </tr>
          <tr><td class="key"><label for="icon_filename"><?php echo JText::_('ICON FILENAME COLON'); ?></label></td>
              <td><?php echo $lists['icon_filenames']; ?></td>
          </tr>
          <tr><td class="key"><?php echo JText::_('URL'); ?></td>
              <td><?php echo $row->url; ?></td>
          </tr>
          <tr><td class="key"><?php echo JText::_('FILE TYPE COLON'); ?></td>
              <td><?php echo $row->file_type; ?></td>
          </tr>
          <tr><td class="key"><?php echo JText::_('FILE SIZE COLON'); ?></td>
              <td><?php echo $row->size; ?> <?php echo JText::_('KB'); ?></td>
          </tr>
        <tr><td class="key"><?php echo JText::_('PUBLISHED COLON'); ?></td>
            <td><?php echo $lists['published']; ?></td>
        </tr> 

        </table> 
        </fieldset> 
        <input type="hidden" name="id" value="<?php echo $row->id; ?>" /> 
        <input type="hidden" name="option" value="<?php echo $option;?>" /> 
        <input type="hidden" name="task" value="edit" />
        <?php echo JHTML::_( 'form.token' ); ?>
        </form> 
        <?php 
    }


    function newAttachment( $article_id, $lists, $option, $from=false ) 
    {
        global $mainframe;
        $db =& JFactory::getDBO();

        // Add the plugins stylesheet to style the list of attachments
        $document = & JFactory::getDocument();
        $document->addStyleSheet( $mainframe->getSiteURL() . 'plugins/content/attachments.css', 
                  'text/css', null, array() );

        // Get the article title (if any)
        $article_title = false;
        if ( $article_id ) {
            // Get the article names
            $query = "SELECT * FROM #__content WHERE id='$article_id' LIMIT 1";
            $db->setQuery($query);
            $rows = $db->loadObjectList();
            if ( count($rows) != 1 ) {
                $errmsg = JText::_('ERROR INVALID ARTICLE ID') . " ($article_id)";
                echo "<script> alert('$errmsg'); window.history.go(-1); </script>\n";
                exit();
                }
            $article_title = $rows[0]->title;
            }
        if ( $article_title ) {
            echo "<h1><b>" . JText::_('ARTICLE') . "</b> &ldquo;$article_title&rdquo;</h1>";
            }

        // Show the existing attachments
        require(JPATH_SITE.DS.'components'.DS.'com_attachments'.DS.'helper.php');
        echo AttachmentsHelper::attachmentsTableHTML($article_id,'Existing Attachments:',false,false,false);

        // Handle the from option
        if ( $from ) 
            $fromval = $from;
        else
            $fromval = '';

        $save_url = JRoute::_(JURI::root() . "administrator/index.php?option=com_attachments&task=save");
        ?>
    
        <form class="attachmentsBackend" enctype="multipart/form-data" 
              name="adminForm" id="adminForm"
              action="<?php echo $save_url; ?>" method="post">
            <fieldset class="adminform">
                <legend><?php echo JText::_('ADD ATTACHMENT'); ?></legend>
                <?php if ( $article_id ) { ?>
                    <p><input type="hidden" name="article_id" value="<?php echo $article_id; ?>" /></p>
                <?php } else { ?>
                    <p><label for="article_id"><b><?php echo JText::_('SELECT ARTICLE'); ?> </b></label> 
                    <?php echo $lists['articles']; ?> </p>
                <?php } ?>
                <p><label for="upload"><b><?php echo JText::_('ATTACH FILE'); ?></b></label> 
                   <input type="file" name="upload" id="upload" size="68" maxlength="512" /></p>
                <p><label for="display_filename"
                          title="<?php echo JText::_('DISPLAY FILENAME TOOLTIP'); ?>"
                          ><b><?php echo JText::_('DISPLAY FILENAME COLON'); ?></b></label> 
                   <input type="text" name="display_filename" id="display_filename" size="70" maxlength="80" 
                          title="<?php echo JText::_('DISPLAY FILENAME TOOLTIP'); ?>"
                          value="" />&nbsp;<?php echo JText::_('(OPTIONAL)'); ?></p>
                <p><label for="description"><b><?php echo JText::_('DESCRIPTION COLON'); ?></b></label> 
                   <input type="text" name="description" id="description" size="70" maxlength="255" value="" /></p>
            </fieldset>
            <input type="hidden" name="MAX_FILE_SIZE" value="524288" />
            <input type="hidden" name="option" value="<?php echo $option;?>" /> 
            <input type="hidden" name="task" value="new" />
            <input type="hidden" name="from" value="<?php echo $fromval; ?>" />
            <?php if ( $from == 'closeme' ): ?>
            <div align="center">
               <input type="submit" name="Submit" class="button" 
                      onclick="javascript: submitbutton('saveNew')"
                      value="<?php echo JText::_('UPLOAD'); ?>" />
            </div>
            <?php endif; ?>
            <?php echo JHTML::_( 'form.token' ); ?>
        </form>
        <?php
    }
}
?>

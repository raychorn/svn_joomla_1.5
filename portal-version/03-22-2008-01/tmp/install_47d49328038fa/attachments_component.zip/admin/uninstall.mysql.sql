DROP TABLE `#__attachments`;

<?php
// $Id: index.php 462 2007-12-10 00:05:53Z fxstein $
/*-----------------------------------------------
this is a dummy file and intentionally left blank
do not remove from ditribution package
/*----------------------------------------------*/
?>
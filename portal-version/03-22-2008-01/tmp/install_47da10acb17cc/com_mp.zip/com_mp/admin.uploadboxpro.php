<?php
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
if (file_exists($mosConfig_live_site.'/mppublish/install.htm')) {
	echo "<a href=\"".$mosConfig_live_site."/mppublish/install.htm\" title=\"View readme\ target=\"_blank\">VIEW README</a>";
} else {
	echo"Your Media Publisher Install is not Complete Please copy the mppublish directory to the HOONLA INSTALL ROOT ";
}
?>
<style type="text/css">
<!--
.style1 {color: #FF0000}
.ppal {
	float: left;
	width: 30%;
}
.gpay {
	float: right;
	width: 55%;
}
.clr {
	clear: both;
}
.content {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
-->
</style>
<div class="content">
  <h3>License:</h3>
  <p><strong>Attribution-NonCommercial-ShareAlike 2.5 </strong></p>
  <p>This license lets you remix, tweak, and build upon our work  non-commercially, as long as you credit <a href="http://www.xsstreamstudio.com ">xsstreamstudio</a> and license new  creations under the identical terms. Others can download and  redistribute our work just like the by-nc-nd license, but they can  also translate, make remixes, and produce new apps based on our  work. All new work based on our work must carry the same license, so any  derivatives will also be non-commercial in nature. </p>
  <p>You must purchase  this application from xsstreamstudio for commercial use slaes: <a href="http://www.xsstreamstudio.com "> http://www.xsstreamstudio.com </a></p>
  <p><strong>CLICK BELOW TO PURCHASE USING PAYPAL OR GOOGLE CHECKOUT </strong></p>
  <p>
  <div class="ppal">
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="cmd" value="_s-xclick">
      <input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but01.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
      <img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
      <input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHXwYJKoZIhvcNAQcEoIIHUDCCB0wCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBspQFeD8eSpl3Pg4L6aMRnGbYaZOCI0un3Uro4utQsJuMV/MEH91bHdezJkSxFOLPgpsixJr712VzNQTMa+so55dtS/rTbKUqN49WXAcXIM73/nDr8C4z9zqn8aeXuJkUDpHzki2yMS+f0Yu5632/JCFnZHM4dYNekLewTdcT9FzELMAkGBSsOAwIaBQAwgdwGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIry2vcqfj7wKAgbjWFrgSd/MAnTCTWIznGmYxIYmWYscF0b0KmUxDO83yqE8pHa7/wVcwtQbVrMYp0th15IPrlXISqyOzt9NjTPHNIuqgWy41i9BtwXa/dWyrzh4mvQDt8nTFGmixwqY4hyq98fxWt3NcZhikOZycGyajtUmKZ+lmE3IKlstjEq1yDJLvFA+kCeMVvTN1FYDqpabaY5QD0e7WonqPPEslqn97gfRQjKAMPONeVUHlOZqvrxqvnXFUgz+0oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDYxMTAxMTM0MTE5WjAjBgkqhkiG9w0BCQQxFgQUR6c7k9NI+Ou24OxoSKtZVc6jbOUwDQYJKoZIhvcNAQEBBQAEgYBX/RUcOh/pSRMGuWMGw1TEh1P0rTnr0Y9bB/RgooHLmFSiHXp4UWR3WgUIClZ5zCK4Voykn/IR9ei2JhbOGhBRmgIdou3O/yUotIYro39yHE9RFhB/e+espyJiv4djTgqQIPtGcFYLollueEocoy7of/vaLJ0n8ip73fo7f8s15g==-----END PKCS7-----
">
    </form>
    </div>
  <div class="gpay">
    
    <form action="https://checkout.google.com/cws/v2/Merchant/272651098323106/checkout" id="wagt_buynow_1" method="post" name="wagt_buynow_1">
    <input name="cart" type="hidden" value="PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjxjaGVja291dC1zaG9wcGluZy1jYXJ0IHhtbG5zPSJodHRwOi8vY2hlY2tvdXQuZ29vZ2xlLmNvbS9zY2hlbWEvMiI+DQogIDxzaG9wcGluZy1jYXJ0Pg0KICAgIDxpdGVtcz4NCiAgICAgIDxpdGVtPg0KICAgICAgICA8cXVhbnRpdHk+MTwvcXVhbnRpdHk+DQogICAgICAgIDx1bml0LXByaWNlIGN1cnJlbmN5PSJVU0QiPjM1LjAwPC91bml0LXByaWNlPg0KICAgICAgICA8aXRlbS1uYW1lPk1lZGlhIFB1Ymxpc2hlcjwvaXRlbS1uYW1lPg0KICAgICAgICA8aXRlbS1kZXNjcmlwdGlvbj5NZWRpYSBQdWJsaXNoZXIgZm9yIEpvb21sYTwvaXRlbS1kZXNjcmlwdGlvbj4NCiAgICAgIDwvaXRlbT4NCiAgICA8L2l0ZW1zPg0KICA8L3Nob3BwaW5nLWNhcnQ+DQogIDxjaGVja291dC1mbG93LXN1cHBvcnQ+DQogICAgPG1lcmNoYW50LWNoZWNrb3V0LWZsb3ctc3VwcG9ydD4NCiAgICAgIDxwbGF0Zm9ybS1pZD44MTkzMjE1MDI5NDc3MTU8L3BsYXRmb3JtLWlkPg0KICAgIDwvbWVyY2hhbnQtY2hlY2tvdXQtZmxvdy1zdXBwb3J0Pg0KICA8L2NoZWNrb3V0LWZsb3ctc3VwcG9ydD4NCjwvY2hlY2tvdXQtc2hvcHBpbmctY2FydD4=" />
    <input name="signature" type="hidden" value="vItyWU2bYsfd3TwPtfFD6iIXhEc=" />
    <input name="image" type="image" alt="Buy Now" src="https://checkout.google.com/buttons/buy.gif?merchant_id=272651098323106&w=117&h=48&style=white&variant=text&loc=en_US" />
</form>
    </div>
  <div class="clr"><!--Content for  class "clr" Goes Here -->
  </div>
  </p>
</div>

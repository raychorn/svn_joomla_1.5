<?
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


// load the html drawing class
//require_once( $mainframe->getPath( 'front_html' ) );

global $database, $my;
global $mosConfig_live_site;

$return = mosGetParam( $_SERVER, 'REQUEST_URI', null );
$return = ampReplace( $return );

$menu = new mosMenu( $database );
$menu->load( $Itemid );
$params = new mosParameters( $menu->params );

//$params->def( 'page_title', 1 );
//grab menu parameters


$index= 0;

//=======================================================

//==========DB GLOBALS===================================
$mosConfig_host ;   //db host
$mosConfig_db ; //dbname
$mosConfig_user ;//db user
$mosConfig_password ;//dbpass
$mosConfig_dbprefix ;//dbprefix
//---------------

//create variables from joomla menu parameters
//===========================================

$u_file = $params->get( 'uploadfile');
$u_size = $params->get( 'maxuploadsize');
$u_mediafiles = $params->get( 'mediafiles');
$u_imagefiles = $params->get( 'imagefiles');
$u_instructions = $params->get( 'instructions');

if ($_GET['mp_catid']) {
$u_category1 = $_GET['mp_name'];
$u_category2 = $_GET['mp_catid'];
$u_category3 = $_GET['mp_section'];
} else {
$u_category1 = $params->get( 'categories1');
$u_category2 = $params->get( 'categories2');
$u_category3 = $params->get( 'categories3');
$u_auto = $params->get( 'auto');
}

//******************************************************************************
// Include ezSQL core ==========================================
include_once "mppublish/shared/ez_sql_core.php";
// Include ezSQL database specific component
include_once "mppublish/ez_sql_mysql.php";

//db settings ==================================================
$db_user = $mosConfig_user;
$db_password = $mosConfig_password;
$db_name = $mosConfig_db;
$db_host = $mosConfig_host;
// Initialise database object and establish a connection
// at the same time - db_user / db_password / db_name / db_host
$db = new ezSQL_mysql($db_user,$db_password,$db_name,$db_host);
//***********************************************************************************

//************************************************************************************


//echo "ID:".$c_user."joomlaid ".$my->id ;
/*$m_query = "SELECT * FROM #__content WHERE id = $aid.";
$database->setQuery( $m_query );
$rows = $database->loadObjectList();
$row = $rows[0];*/


?>


<div style="text-align:left; width:90%; margin-left:auto; margin-right:auto; margin-top:25px;">
<!--use clsss ubox_info to style the instructions -->
<div class="ubox_info">
<? echo $u_instructions ;?>
</div>
<script type="text/javascript" src="http://www.clipbox99.com/widgets/swfobject.js"></script>
<div id="flashcontent">
   OPPS your Javascript seems disabled
</div>
<script type="text/javascript">
   var so = new SWFObject("components/com_uploadboxpro/mediauploadproV1.swf", "videoUploadBoxProLegal", "600", "550", "8,0,0,0", "#ffffff");
   so.addParam("quality", "high");
   so.addParam("wmode", "transparent");
   so.addVariable("maxUploadSize", "<? echo $u_size; ?>");
   so.addVariable("siteWWW", "<? echo $_SERVER['SERVER_NAME'] ; ?>");
   so.addVariable("uploadfile", "<? echo $mosConfig_live_site ?>/mppublish/upload.php");
   so.addVariable("uploadimage", "<? echo $mosConfig_live_site ?>/mppublish/uploadimg.php");
   so.addVariable("add_article", "<? echo $mosConfig_live_site ?>/mppublish/addarticle.php");
   so.addVariable("username", "<? echo $my->username ?>");
   so.addVariable("userid", "<? echo $my->id ?>");
 //SET FILE PERMISSIONS
//TO ADD EXTENSIONS seperate extensions name (*.ext) by ";"
//To remove extensions simply delete them to remove categore leave it blank ("")
  // so.addVariable("flashext", "*.swf;*.flv;*.mp3;*.wma;*.mov;*.wmv;*.mpg;*.mp4");
   so.addVariable("flashext", "<? echo $u_mediafiles ; ?>");
   so.addVariable("imgext", "<? echo $u_imagefiles ; ?>");
   so.addVariable("channel_cb", "<? echo $u_category1 ; ?>");
   so.addVariable("categoryid", "<? echo $u_category2 ; ?>");
   so.addVariable("section", "<? echo $u_category3 ; ?>");
   so.addVariable("autopublish", "<? echo $u_auto ; ?>");
   so.addVariable("config", "1");
   so.write("flashcontent");
</script>
</div>





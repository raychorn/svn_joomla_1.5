<?php
/*
Created using the Mambo Addon Wizard - http://www.PunkSoftware.com
*@ uploadboxpro
*@ Package uploadboxpro
*@ (C) 2006 Shawn Sandy
*@ Copyright 2006 - Shawn Sandy
*@ version 1.0
*/

function com_uninstall() {
echo<<<ENDUNINSTALLMSG
Thank you forTrying Shawn Sandy's uploadboxpro Component...<br/>
<br/>
<a href="http://www.sstreamtv.com">http://www.sstreamtv.com</a>
ENDUNINSTALLMSG;
}
?>

<?php
/*
Created using the Mambo Addon Wizard - http://www.PunkSoftware.com
*@ uploadboxpro
*@ Package uploadboxpro
*@ (C) 2006 Shawn Sandy
*@ Copyright 2006 - Shawn Sandy
*@ version 1.0
*/

function com_install() {
echo<<<ENDINSTALLMSG
Thank you for Installing Shawn Sandy's uploadboxpro Component...<br/>
If you have any questions, please contact Shawn Sandy at <a href="mailto:shawnsandy04@gmail.com">shawnsandy04@gmail.com</a><br/>
<br/>
<a href="http://www.sstreamtv.com">http://www.sstreamtv.com</a>
ENDINSTALLMSG;
}
?>

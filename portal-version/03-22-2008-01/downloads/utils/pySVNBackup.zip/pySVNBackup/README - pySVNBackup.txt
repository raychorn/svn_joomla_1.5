pySVNBackup allows you to backup your SVN Database through the use of a ZIP file dated with a timestamp for each use.

One day whilst happily using SVN I happened to commit some files or a nondescript nature and WHAMO next I see some error messsages of a distressing nature.

Say What ?

You heard it right.

I found myself in the midst of a real honest to Tigris bug and my SVN database turned to dust right before my eyes.

After no few frantic Google searches I learned there is a bug in the Berkeley Sleepy Cat Database code that can cause an SVN database to become quite corrupt.

Then as if a shining light had pierced my forehead it came to me.  I would create pySVNBackup and my SVN worries would be over.

What is pySVNBackup anyway ?

pySVNBackup performs a very nice SVN backup whenever I need such a backup to take place.

pySVNBackup takes all my SVN files and puts them into a single ZIP file with a nice timestamp for each use.  

I keep all these ZIP files around for about a month then I remove the backups from the previous month.

pySVNBackup might just work for you.  I have included both the source and the compiled EXE for your amusement.  

Be sure to modify the .yml file for your specific needs.

You will notice the .yml file contains a different setup for each machine - this allows pySVNBackup to be deployed on shared folders to be used by different computers from a central location, if necessary.


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

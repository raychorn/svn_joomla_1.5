pyAIRDemo - This is a DEMO that show how easy it is to make Python augment an Adobe AIR Application.

I have been coding Flex Apps for about 4 years by now and one day this thought hit me like a ton of bricks.

"Why not make Python augment an Adobe AIR App ?!?"

What did I just say ?

ActionScript 3 is a fine langauge when it comes to coding GUI behaviors.  But when it comes to coding powerful applications, well let's just say Python is better suited than AS3 could ever be.

So riddle me this.

What happens if I make Adobe AIR connect somehow to a Python middle-tier such that I am able to magically make Python handle all the heavy lifting for my Adobe AIR front-end ?!?

Imagine you are able to package your Python code in a single EXE with the ability to automatically install the correct Adobe AIR Runtime along with the Adobe AIR Application.

Simple, isn't it ?!?

Stay tuned for the pyAIR Framework.

pyAIR features:

* Ability to plug-in your own Python modules at runtime.
* Ability to deploy your Python code along with your Adobe AIR Application.
* Ability to deploy high-powered Python-based Object-Oriented Databases (no database server required).

We are also working on a nice GUI based Packager for pyAIR that allows for quick deployments of pyAIR Apps.

We believe Python and Adobe AIR were made for each other.

We believe pyAIR is the humble beginning for pyFusion that allows Python code to be fused together with Adobe AIR -- almost like Adobe ColdFusion is being reimagined using the Python language rather than the Java Language.

ColdFusion is a very expensive product - the Enterprise version will still set you back $7499.00 (I kid you not!).

What features does ColdFusion Enterprise provide for all this money ?

Performance increases  ....................... Python 2.5.2 plus Psyco runs faster than compiled Java, hands-down !
Server Monitor  .............................. okay but you cannot deploy ColdFusion on the Desktop !
PDF features  ................................ I kid you not, it is so easy to get PDF content out of any Flash or Flex App this is hardly a selling point.
Ajax features ................................ Yeah, this is cool but Adobe AIR already knows how to do AJAXian behaviors with any back-end you want.
.NET integration ............................. Well you can deploy .Net on the Desktop but you would be hard-pressed to deploy an auto-installer for the runtime.
Microsoft Exchange Server integration ........ You get this with Win32 !
Interactive debugger ......................... Wing IDE gives you an interactive debugger for your Python code.  Flex Builder 3 gives you a debugger for the GUI.
Adobe Flex integration ....................... Bingo - pyAIR gives you Flex Integration.
Per-application settings ..................... Yup, pyAIR does this too.
Multi-threading .............................. Python knows all about multi-threaded through the use of a nice little function decorator.
Image manipulation ........................... Python knows all about manipulating images.
Presentations on demand ...................... Flex 3 knows all about this feature too.
Atom and RSS feeds ........................... This is a 2 second no-brainer.
ZIP and JAR file features .................... Python knows all about handling ZIP content - built into the language.
User-based Administrator and RDS access ...... Python allows developers to integrate their AIR app right into the OS.
Improved file manipulation functions ......... Python knows how to handle files at a very low-level.
JavaScript operators in CFML ................. No need to bother with JavaScript when using pyAIR.
CFC improvements ............................. What ?  Who cares about CFC's when using Python ?!?
Strong encryption libraries .................. There are oodles of Python encryption modules available at no cost.
Reporting enhancements ....................... Okay, so you need to write some code to handle your reporting needs. Big deal.
Database interaction improvements ............ Python knows all about interacting with any Relational database on the planet.
Argument collections ......................... Python knows more about how to handle Lists so who cares about Collections ?!?
Array and structure creation improvements .... Python does this better too.
Expanded platform, OS, and database support .. Python can do anything ColdFusion Enterprise can do better !

The bottom line is this.

If you really want to spend $7500 for each CPU your ColdFusion code runs on then by all means buy ColdFusion Enterprise.

ColdFusion Enterprise cannot be deployed to the Desktop no matter how hard you try.  

Well you could deploy the Developer's Edition of ColdFusion on every single Desktop you intend to deploy your AIR app onto but I am sure Adobe would not be pleased with this arrangement at-all.

pyAIR provides all the power you want for your stand-alone Desktop Apps !


pyAIRDemo is a Proof-of-Concept that proves it is possible to augment an Adobe AIR App through the use of Python.

Why didn't we expose all the source to you ?

This is a good question, I suppose, however our purpose for publishing the Proof-of-Concept was to prove we could use Python to create a free-standing EXE that contains the entire Python interpreter along with the business logic for our Adobe AIR App.  We felt this could be done in an adequate manner without having to bore everyone with the details of the specific source code we used to accomplish all of this.  And we feel this specific combination of technologies is just interesting enough to be commercially viable either as an SDK or as a vehicle for the production of various Adobe AIR Apps.

Now for some background on pyAIR.

pyAIR provides a framework within which a developer can deploy Python based applications that use Adobe AIR for the GUI.

pyAIR features an automated BUILD system that allows developers to Package AIR Applications that contain embedded Python scripts in such a manner so as to allow the Adobe AIR Apps to dynamically execute Python scripts at runtime.

pyAIR also features an automated PACKAGING system that allows developers to package Adobe AIR Apps that use pyAIR in a seamless manner.

pyAIR also features a Dialog Builder that allows developers to fully script their installation process.

pyAIR provides for automatic deployment (if required) of the Adobe AIR Runtime - this allows developers the ability to specify which version of Adobe AIR they wish to use upon deployment.  pyAIR automatically determines if the Adobe AIR Runtime that was deployed needs to be installed or not - Adobe AIR Runtime is only installed when required.

Some ideal uses for pyAIR include:  Games, Business Apps, Compiler Tools and others.

pyAIR currently supports Windows however pyAIR will be updated to support any OS platforms supported by Adobe AIR.


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

pyFargoReports exists to facilitate your ability to report on previously parsed data taken from Wells Fargo Bank Statements that exist as PDF documents as generated from the San Francisco Branch of the Wells Fargo Bank.

See also: pyFargo for the part of this system that does the parsing.

Directions for use: (Steps 1 thru 5 pertain to pyFargo, step 6 is for pyFargoReports)

1). Download your PDF Statements and place them all into the same folder.

2). Use Adobe Acrobat 8 to save all PDF content as ASCII text files.

3). Modify the contents of pyFargo.py to have access to your files.

4). Satisfy the requirements of pyFargo.py - some text files may require some modifications to allow the parser to properly parse the data - sorry but it was not possible to tweak the parser to handle all the wierdness imposed by the Adobe Acrobat 8 behaviors when it tries to save PDF content as text.

5). Make sure your amounts reconcile from your statements before you trust the results.

6). Produce your reports using pyFargoReports.py

7). Have fun.

8). If you need support you may contact the author to negotiate a support contract.

Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

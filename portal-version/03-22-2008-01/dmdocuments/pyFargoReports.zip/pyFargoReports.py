import os
import sys
from lib import floatValue
import globalVars
from lib import AccumulatorHash
from lib.gds import julian
from lib import QIF
from lib import oodb
from lib.oodb import Enum
from lib.oodb import PickledHash
from lib.oodb import PickleMethods
from lib import _utils

#_yyyy = 2005

#_yyyy = 2006

_yyyy = 2007

_money_dbx = -1

_money_data = AccumulatorHash.HashedLists()
_money_data_checks = {}

_deposits_classified = {}
_classified_deposits = AccumulatorHash.HashedLists()

_withdrawls_classified = {}

_w2_date_ranges = {}

_w2_data_2005 = AccumulatorHash.HashedLists()

_w2_data_2005 = AccumulatorHash.HashedLists()

#_w2_data_2005['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,00.00',floatValue.Options.asDollar)
#_w2_data_2005['Your-Employer-Name-Goes-Here'] = '01-01-2005'
#_w2_data_2005['Your-Employer-Name-Goes-Here'] = '06-30-2005'

_w2_data_2007 = AccumulatorHash.HashedLists()

#_w2_data_2007['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$100.00',floatValue.Options.asDollar)
#_w2_data_2007['Your-Employer-Name-Goes-Here'] = '02-10-2007'
#_w2_data_2007['Your-Employer-Name-Goes-Here'] = '02-17-2007'

_w2_data_2006 = AccumulatorHash.HashedLists()

_w2_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.78',floatValue.Options.asDollar)
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '04-18-2006'
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '06-15-2006'

_w2_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.00',floatValue.Options.asDollar)
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '01-20-2006'
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '04-15-2006'

_w2_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.93',floatValue.Options.asDollar)
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '08-14-2006'
_w2_data_2006['Your-Employer-Name-Goes-Here'] = '10-15-2006'

_w2_data_by_year = {}
_w2_data_by_year[2005] = _w2_data_2005
_w2_data_by_year[2006] = _w2_data_2006

_w2_missing_data_2006 = AccumulatorHash.HashedLists()
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.37',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.00',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,004.24',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.92',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,000.49',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,011.46',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,001.86',floatValue.Options.asDollar)
_w2_missing_data_2006['Your-Employer-Name-Goes-Here'] = floatValue.floatValue('$1,001.09',floatValue.Options.asDollar)

_w2_missing_data_by_year = {}
_w2_missing_data_by_year[2006] = _w2_missing_data_2006

class DepositsClassifications(Enum):
    no_classification = 0
    google_adsense = 2**0
    atm_deposit = 2**1
    atm_check_deposit = 2**2
    purchase_return = 2**3
    payroll = 2**4
    tax_refund = 2**5
    misc_deposit = 2**6
    bank_fee_rebate = 2**7
    tax_fin_deposit = 2**8
    payroll_advance = 2**9
    funds_transfer = 2**10
    funds_from_wife = 2**11
    my_Payroll = 2**12

def classifyDeposit(dList):
    item = dList[1].lower()
    if (_yyyy == 2005):
        if ( (dList[0] == '03/07') or (dList[0] == '04/12') ):
            return DepositsClassifications.my_Payroll
        if ( (dList[0] == '07/05') or (dList[0] == '07/07') ):
            return DepositsClassifications.my_Payroll
        if ( (dList[0] == '08/12') or (dList[0] == '11/04') ):
            return DepositsClassifications.my_Payroll
        if ( (dList[0] == '11/16') or (dList[0] == '12/05') or (item.find('trinet payroll') > -1) ):
            return DepositsClassifications.my_Payroll
    if (item.find('google adsense') > -1):
        return DepositsClassifications.google_adsense
    elif (item.find('atm deposit') > -1):
        return DepositsClassifications.atm_deposit
    elif (item.find('atm check deposit') > -1):
        return DepositsClassifications.atm_deposit
    elif (item.find('check crd pur rtrn') > -1):
        return DepositsClassifications.purchase_return
    elif (item.find('payroll') > -1):
        return DepositsClassifications.atm_deposit
    elif (item.find('salary') > -1):
        return DepositsClassifications.atm_deposit
    elif ( (item.find('tax-refund') > -1) or (item.find('tax refund') > -1) ):
        return DepositsClassifications.tax_refund
    elif (item == 'deposit'):
        return DepositsClassifications.misc_deposit
    elif (item.find('advance') > -1):
        return DepositsClassifications.payroll_advance
    elif (item.find('discount') > -1):
        return DepositsClassifications.bank_fee_rebate
    elif (item.find('billpay refund') > -1):
        return DepositsClassifications.bank_fee_rebate
    elif (item.find('transfer') > -1):
        return DepositsClassifications.funds_transfer
    elif (item.find('tax fin') > -1):
        return DepositsClassifications.tax_fin_deposit
    return DepositsClassifications.no_classification

class WithdrawlsClassifications(Enum):
    no_classification = 0
    business_meal = 2**0
    business_travel = 2**1
    petty_cash = 2**2
    advertising = 2**3
    shipping_and_receiveing = 2**4
    business_research = 2**5
    medical_expense = 2**6
    computer_hardware_software = 2**7
    banking_fees = 2**8
    business_utilities = 2**9
    repairs = 2**10
    vehicle_expense = 2**11
    tax_preparation_fees = 2**12
    business_entertainment = 2**13
    insurance_and_fees = 2**14
    patents_and_trademarks = 2**15
    business_clothing = 2**16
    education_expenses = 2**17
    office_supplies = 2**18
    office_furniture = 2**19
    legal_fees = 2**20
    business_rent = 2**21
    vehicle_purchase = 2**22
    pet_expense = 2**23
    petty_cash_paypal = 2**24

def classifyWithdrawl(dList, phase=None):
    item = dList[1].lower()
    if (item.find('restaurant') > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find('albertsons') > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find('safeway store') > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("applebee") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("vending") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("stadium") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("grill") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("aramark") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("starbucks") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("margaritas") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("freshens") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("olive gard") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("pasta") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("resta") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("hungry") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find("nob hill") > -1):
        return WithdrawlsClassifications.business_meal
    elif (item.find('fuel') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('travelocity') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('shell oil') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('delta air') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('full serve') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('disney world') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('car rental') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('airport') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('inn') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('fastrak') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('tire') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('bart') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('oil change') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('exxon') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('hess') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('wash metro') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('parking') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('turnpk') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('svc station') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('resorts') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('flowers') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('travel') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('jetblue') > -1):
        return WithdrawlsClassifications.business_travel
    elif (item.find('paypal') > -1):
        return WithdrawlsClassifications.petty_cash
    elif (item.find('ebay') > -1):
        return WithdrawlsClassifications.advertising
    if (phase == None):
        if (_money_data_checks.has_key(dList[1])):
            chk = _money_data_checks[dList[1]]
            dList[1] = '%s %s %s' % (chk.memo,chk.payee,chk.category.replace(':',' '))
            classifyWithdrawl(dList,1)
    pass
    return WithdrawlsClassifications.no_classification

def detailsForCheckByNumber(chkNum):
    if (not isinstance(chkNum,str)):
        chkNum = '%d' % chkNum
    if (_money_data_checks.has_key(chkNum)):
        chk = _money_data_checks[chkNum]
        return 'Check #%s %s %s %s' % (chkNum,chk.memo if chk.memo else '',chk.payee if chk.payee else '',chk.category.replace(':',' ') if chk.category else '')
    return chkNum

def total_w2_data():
    total_w2s = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    if (_w2_data_by_year.has_key(_yyyy)):
        for k,v in _w2_data_by_year[_yyyy].iteritems():
            total_w2s += v[0]
            if (len(v) > 1):
                v[1:] = [d.split('-') for d in v[1:]]
                x = []
                for d in v[1:]:
                    x.append([int(n) for n in d])
                v[1:] = x
                v[1:] = [(d,julian.DayOfYear(d[0],d[1],d[2])) for d in v[1:] if len(d) == 3]
                begin = v[1:][0][-1]
                end = v[1:][-1][-1]
                _w2_date_ranges[(begin,end)] = k
    return total_w2s

def reverseDepositsByClassifications():
    for k,v in _deposits_classified.iteritems():
        _classified_deposits[v[0] if isinstance(v,list) else str(v)] = k.split(',')
    if (0):
        items = _classified_deposits[DepositsClassifications.atm_deposit]
        for item in items:
            val = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
            if (isinstance(item[0],list)):
                mmDD = item[0][0]
                doy = int(item[0][-1])
                mm,dd = mmDD.split('/')[:2]
            else:
                mmDD = item[0]
                doy = -1
                mm,dd = mmDD.split('/')[:2]
            _dt = '%02d/%02d/%04d' % (int(mm),int(dd),int(_yyyy))
            recs = [_money_dbx[r] for r in _money_dbx.queryMostlyANDitems(_dt,str(val),str(-val)) if _money_dbx.has_key(r)]
            recs = [r for r in recs if r.category ] # str(r.category).lower().find('payroll') > -1
            if len(recs) > 0:
                print '(reverseDepositsByClassifications) :: '
                for rec in recs:
                    print '\t%s' % str(item)
                    print '\t%s' % rec.pretty()
                    print '\t%s' % '='*30
    pass

def w2_employer_for_day_of_year(doy):
    for k,v in _w2_date_ranges.iteritems():
        if ( (doy >= k[0]) and (doy <= k[-1]) ):
            return v
    return ''

def w2_employer_delta_days_of_year(doy):
    d = {}
    for k,v in _w2_date_ranges.iteritems():
        d[doy - k[-1]] = v
    return d

def handle_missing_w2_for_employer(item,employer):
    isFound = False
    if (_w2_missing_data_by_year.has_key(employer)):
        val_item = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
        if (val_item in _w2_missing_data_by_year[employer]):
            for i in xrange(0,len(_w2_missing_data_by_year[employer])):
                if (_w2_missing_data_by_year[employer][i] == val_item):
                    isFound = True
                    del _w2_missing_data_by_year[employer][i]
                    break
    return isFound

def actualYearBasedOnMonthDay(mm,dd,yyyy):
    if ( (mm == 12) and (dd < 8) ):
        return yyyy-1
    return yyyy

def gather_w2_data_for_dates():
    db = AccumulatorHash.HashedLists()
    d = _classified_deposits[DepositsClassifications.atm_deposit]
    xfer_from_wife_amount = floatValue.floatValue('900.00',floatValue.Options.asDollar)
    for item in d:
        val = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
        if (val == xfer_from_wife_amount):
            db['Xfer from Wife for Bills'] = item
        else:
            dt = item[0].split('/')[:2]
            dt = [int(n) for n in dt]
            doy = julian.DayOfYear(dt[0],dt[1],actualYearBasedOnMonthDay(dt[0],dt[1],_yyyy))
            item[0] = [item[0],doy]
            employer = w2_employer_for_day_of_year(doy)
            db[employer] = item
            handle_missing_w2_for_employer(item,employer)
    if (_w2_data_by_year.has_key(_yyyy)):
        for k,v in db.iteritems():
            if (_w2_data_by_year[_yyyy].has_key(k)):
                vals = [floatValue.floatValue(item[-1],floatValue.Options.asDollar) for item in v]
                total_vals = sum(vals)
                expected_total = _w2_data_by_year[_yyyy][k][0]
                if (total_vals != expected_total):
                    diff_val = max(total_vals,expected_total) - min(total_vals,expected_total)
                    if (diff_val in vals):
                        i = vals.index(diff_val)
                        db[''] = v[i]
                        del v[i]
                    doys = [item[0][-1] for item in v]
                    doys.sort()
                    diffs = [0]
                    dayNum = doys[0]
                    for doy in doys[1:]:
                        diffs.append(doy - dayNum)
                        dayNum = doy
                    pass
    return db

def sortItemsBasedOnDOY(items):
    d = AccumulatorHash.HashedLists()
    for item in items:
        if (not isinstance(item[0],list)):
            toks = [int(n) for n in item[0].split('/')]
            if (len(toks) == 2):
                toks.append(_yyyy)
            if (len(toks) == 3):
                item[0] = [item[0],julian.DayOfYear(toks[0],toks[1],actualYearBasedOnMonthDay(toks[0],toks[1],toks[-1]))]
    for item in items:
        d[item[0][-1]] = item
    keys = d.keys()
    keys.sort()
    _items = []
    for k in keys:
        for n in d[k]:
            _items.append(n)
    return _items

def redactDetails2(item):
    iBegin = item.find('?MCC=')
    if (iBegin > -1):
        item = item[0:iBegin] # + item[1][iEnd:]
    return item

def redactDetails(item):
    iBegin = item.find('4873')
    if (iBegin > -1):
        iEnd = item.find('7156')
        item = item[0:iBegin] # + item[1][iEnd:]
    return redactDetails2(item)

def reportDeposits():
    deposits = globalVars.dataFilesFor(globalVars.DataFileTypes.deposits,_yyyy)
    k_deposits = []
    for f in deposits:
        dbx = PickledHash(globalVars.PathName(f))
        for k,v in dbx.iteritems():
            _deposits_classified[','.join(v)] = [classifyDeposit(v)]
            k_deposits.append(v)
        dbx.close()
    assert len(k_deposits) == len(_deposits_classified.keys()), 'Oops, something went wrong with the way deposits are being handled.'
    d = {}
    cd = AccumulatorHash.HashedLists()
    total_deposits = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    for k,v in _deposits_classified.iteritems():
        val = k.split(',')
        total_deposits += floatValue.floatValue(val[-1],floatValue.Options.asDollar)
        if (v[0] == DepositsClassifications.no_classification):
            d[k] = v
        else:
            cd[v[0]] = val
    assert len(d) == 0, 'Oops, forgot to classify %d deposits.\n%s' % (len(d),str(d))
    print 'Total Deposits: $%-10.2f' % total_deposits
    td = {}
    for k,v in cd.iteritems():
        td[k] = floatValue.floatValue('0.0',floatValue.Options.asDollar)
        for item in v:
            td[k] += floatValue.floatValue(item[-1],floatValue.Options.asDollar)
    _total_deposits = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    for k,v in td.iteritems():
        _total_deposits += v
    assert total_deposits == _total_deposits, 'Oops, the Total of Deposits does not match when compared with the total of the Deposits Classifications.'
    w2_total = total_w2_data()
    reverseDepositsByClassifications()
    # gather deposits based on their dates from the viewpoint of the w2 data...
    w2_deposits = gather_w2_data_for_dates()
    for k,v in td.iteritems():
        print '$%10.2f\t%s' % (v,k)
    print
    print 'W2 Analysis:'
    total_payroll_atm_deposits = td[DepositsClassifications.atm_deposit]
    print 'Total for ATM Deposits=$%-10.2f' % (total_payroll_atm_deposits)
    print 'Total for W2 Deposits=$%-10.2f' % (w2_total)
    print '='*30
    print 'Remainder Deposits less W2 Deposits=$%-10.2f' % (total_payroll_atm_deposits-w2_total)
    print
    print '='*30
    print
    print 'W2 Deposit Analysis:'
    _total_for_employers = floatValue.floatValue('0.00',floatValue.Options.asDollar)
    for k,v in w2_deposits.iteritems():
        print
        print '(%s)' % k if len(k) > 0 else 'UNCLASSIFIED'
        _total_per_employer = floatValue.floatValue('0.00',floatValue.Options.asDollar)
        _items = sortItemsBasedOnDOY(v)
        for item in _items:
            val = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
            if (isinstance(item[0],list)):
                mmDD = item[0][0]
                doy = int(item[0][-1])
                mm,dd = mmDD.split('/')[:2]
            else:
                mmDD = item[0]
                doy = -1
                mm,dd = mmDD.split('/')[:2]
            print '$%10.2f\t%s/%s, (#%4d)\t%s' % (val,mmDD,actualYearBasedOnMonthDay(mm,dd,_yyyy),doy,item[1])
            _total_per_employer += val
        print '='*11
        print '$%10.2f Total' % _total_per_employer
        _total_for_employers += _total_per_employer
        print
    print 'Grand Total=$%10.2f' % _total_for_employers
    print
    print '='*30
    isAccountedFor = _total_for_employers == total_payroll_atm_deposits
    print 'All W2 Deposits have %sbeen accounted for however some of them may require re-classification.' % ('NOT ' if not isAccountedFor else '')
    print '='*30
    print
    print 'General Deposit Analysis:'
    _total_for_classes = floatValue.floatValue('0.00',floatValue.Options.asDollar)
    for k,v in cd.iteritems():
        print
        print '(%s)\n' % str(k)
        _total_per_class = floatValue.floatValue('0.00',floatValue.Options.asDollar)
        _items = sortItemsBasedOnDOY(v)
        for item in _items:
            val = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
            if (not isinstance(item[0],list)):
                mmDD = item[0]
                doy = -1
                mm,dd = mmDD.split('/')[:2]
            else:
                mmDD = item[0][0]
                doy = int(item[0][-1])
                mm,dd = mmDD.split('/')[:2]
            print '$%10.2f\t%s/%s, (#%4d)\t%s' % (val,mmDD,actualYearBasedOnMonthDay(mm,dd,_yyyy),doy,redactDetails(item[1]))
            _total_per_class += val
        print '='*11
        print '$%10.2f Total' % _total_per_class
        _total_for_classes += _total_per_class
        print
    print '$%10.2f Grand Total' % _total_for_classes
    print
    print '='*30
    pass

def reportWithdrawls():
    withdrawls = globalVars.dataFilesFor(globalVars.DataFileTypes.withdrawls,_yyyy)
    k_withdrawls = []
    for f in withdrawls:
        dbx = PickledHash(globalVars.PathName(f))
        for k,v in dbx.iteritems():
            if (v[0].isdigit()):
                x = v[0]
                v[0] = v[1]
                v[1] = detailsForCheckByNumber(x)
            s = ','.join(v)
            _withdrawls_classified[s] = [classifyWithdrawl(v)]
            k_withdrawls.append(s)
        dbx.close()
    for k,v in _withdrawls_classified.iteritems():
        if (v[0] == WithdrawlsClassifications.no_classification):
            data = k.split(',')
            data_value = floatValue.floatValue(data[-1],floatValue.Options.asDollar)
            if (data_value == floatValue.floatValue('1550.00',floatValue.Options.asDollar)):
                _withdrawls_classified[k] = [WithdrawlsClassifications.business_rent]
            elif (data_value == floatValue.floatValue('5500.00',floatValue.Options.asDollar)):
                _withdrawls_classified[k] = [WithdrawlsClassifications.education_expenses]
            elif (data[0] == '1000'):
                _withdrawls_classified[k] = [WithdrawlsClassifications.business_utilities]
            elif (data[0] in ['1001','1002']):
                _withdrawls_classified[k] = [WithdrawlsClassifications.medical_expense]
            elif (data[0] == '2000'):
                _withdrawls_classified[k] = [WithdrawlsClassifications.legal_fees]
            elif (data[0] == '3000'):
                _withdrawls_classified[k] = [WithdrawlsClassifications.insurance_and_fees]
            elif (data[0] == '4000'):
                _withdrawls_classified[k] = [WithdrawlsClassifications.medical_expense]
    d = {}
    cd = AccumulatorHash.HashedLists()
    total_withdrawls = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    for k,v in _withdrawls_classified.iteritems():
        val = k.split(',')
        total_withdrawls += floatValue.floatValue(val[-1],floatValue.Options.asDollar)
        if (v[0] == WithdrawlsClassifications.no_classification):
            d[k] = v
        else:
            cd[v[0]] = val
    print 'Total Withdrawals: $%-10.2f' % total_withdrawls
    print '='*80
    print 'UNCLASSIFIED EXPENSES:'
    _d = d.keys()
    _d.sort()
    for k in _d:
        print '%s' % redactDetails(k)
    print '='*80
    print '='*80
    print 'CLASSIFIED EXPENSES:\n'
    cd_total_withdrawls = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    cd_total_withdrawls2 = floatValue.floatValue('0.0',floatValue.Options.asDollar)
    report_details = AccumulatorHash.HashedLists()
    for k,v in cd.iteritems():
        d = AccumulatorHash.HashedLists()
        report_details[k] = '\t%s\n' % str(k)
        cd_total_withdrawls_per_class = floatValue.floatValue('0.0',floatValue.Options.asDollar)
        for item in v:
            val = floatValue.floatValue(item[-1],floatValue.Options.asDollar)
            cd_total_withdrawls += val
            cd_total_withdrawls_per_class += val
            d[item[0]] = item
        d_keys = d.keys()
        d_keys.sort()
        for dk in d_keys:
            for di in d[dk]:
                val = floatValue.floatValue(di[-1],floatValue.Options.asDollar)
                try:
                    mm,dd = di[1].split('/')[:2]
                except:
                    mm,dd = di[0].split('/')[:2]
                report_details[k] = '$%10.2f\t%s/%s\t%s' % (val,di[0],actualYearBasedOnMonthDay(mm,dd,_yyyy),redactDetails(di[1]))
        report_details[k] = ''
        report_details[k] = '='*11
        _line = '$%10.2f Total Withdrawals for %s' % (cd_total_withdrawls_per_class,str(k))
        cd_total_withdrawls2 += cd_total_withdrawls_per_class
        print _line
        report_details[k] = _line
        report_details[k] = ''
        print
    print '$%10.2f Total Classified Withdrawals (%s)' % (cd_total_withdrawls,'VALIDATED' if cd_total_withdrawls == cd_total_withdrawls2 else 'WRONG')
    print '='*80
    print '\n\n'
    print '='*80
    print
    for k,v in cd.iteritems():
        print '\n'.join(report_details[k])
    print '$%10.2f Total Classified Withdrawals' % cd_total_withdrawls
    print '='*80
    pass

def getMoneyCheck(chkNum):
    if (not isinstance(chkNum,str)):
        chkNum = '%d' % chkNum
    if (_money_data_checks.has_key(chkNum)):
        return _money_data_checks[chkNum]
    return None

def main():
    global _money_dbx
    qifReader = QIF.QifReader(None) # ['12/8/%d' % (_yyyy-1),'12/31/%d' % _yyyy]
    fname = qifReader.getDatabaseFileNameFor(_yyyy)
    dbx = PickledHash(fname,PickleMethods.useSafeSerializer)
    _date_vals = oodb.unique([dbx[k] for k in dbx.keys() if k.startswith('__date_')])
    _date_vals.sort()
    _keys = []
    for k in _date_vals:
        val = dbx[k]
        if (isinstance(val,list)):
            for v in val:
                _keys.append(v)
        else:
            _keys.append(v)
    _keys = oodb.unique(_keys)
    _keys.sort()
    _items = [dbx[k] for k in _keys]
    for item in _items:
        _money_data[item.date[-1]] = item
        if (item.checkNumber):
            _money_data_checks['%d' % item.checkNumber] = item
    _money_dbx = dbx
    reportDeposits()
    reportWithdrawls()
    dbx.close()

if (__name__ == '__main__'):
    from lib import _psyco
    _psyco.importPsycoIfPossible()
    if (_utils.getVersionNumber() >= 251):
        main()
    else:
	print 'You seem to be using the wrong version of Python, try using 2.5.1 rather than "%s".' % sys.version.split()[0]

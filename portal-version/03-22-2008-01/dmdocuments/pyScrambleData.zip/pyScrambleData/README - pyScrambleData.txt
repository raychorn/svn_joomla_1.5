pyScrambleData - A classic battle between Python and Ruby 1.8.6 to see which runs faster than the other.

The scenario:

Read a 20 MB file and change all the bytes and then write the changed bytes to a new file.

Sounds pretty simple doesn't it ?

The Python code when run on a dv9000 laptop executes in 0.858 seconds when using Psyco.

The Ruby code when run on the save dv9000 laptop executes in 24.333 seconds.

This means Ruby runs about 24.4 times slower than Python.

People who love coding Ruby like to say how much more "fun" it is to code Ruby.  Or how much faster one can code Ruby than other languages.

Well maybe coding Ruby is more "fun" than coding C++.  Almost any language is more fun to code than C++, let's be real about this.

If you want to code for performance then Ruby is the last language you would want to think about using.

On the other hand.

When I was at BigFix the big Ruby coder, who shall remain nameless, was heavily into coding Ruby for absolutely everything.  

This guy wanted to use Ruby to code an ETL Process for some huge databases and he did this exactly.  

In fact, he led his 3-man development team down the merry path of producing a Ruby-based ETL process and 6 weeks (18 man-weeks) later he completed his Ruby-based ETL process that took 16 hours to run to completion against a 5 GB database.  

Well now this was "fun" to be sure however his company may have thought it more "fun" to have spent less money than 18 man-weeks of salaries to get this same result.  

Shortly after this Mr. Ruby-coder had to suffer through rewriting his ETL process using Perl just to get the runtimes down to something closer to 6 hours.

I managed to get runtimes from Python that were just about 3x faster than Perl.

Is Python "fun" to code ?

Ignore the requirement to make your Python code readable and "yes" Python is fun to code assuming this definition of "fun" also runs reasonably fast or certainly fast enough so you might not have to recode your work using a faster language.

Mr. Ruby-coder from BigFix told me his only problem with Python was all those tabs he had to use when writing his code.  Apparently this guy never found any IDE tools such as Wingware's Wing IDE or Komodo.

The fact that Mr. Ruby-coder at BigFix was using tools like Notepad when writing his code might illuminate his specific problems with the Python language.

On the other hand.

The Ruby language has no specific requirements for making Ruby code "readable".  Mr. Ruby-coder at BigFix was merrily churning-out Ruby code without whitespace and without meaning.  Does this sort of thing make Ruby code easier to read ?  Doubtful to say the least.

The bottom line is this.

Python runs 9x faster than Ruby for real-world programming problems such as crafting an ETL Process on large databases.

Ruby wastes time and money.

Python saves time and money.

Ruby lacks the rich set of data handling functions Python programmers enjoy.

Ruby has no Virtual Machine.

Ruby has no Just-in-Time Compiler.

Python development is light-years ahead of Ruby development across the board.

Python is used for high-powered development projects but Ruby gets used for high-powered projects and then it gets abandoned in favor of Perl, in some cases.

People are successfully using Python for high-powered real-time 3D video games such as Eve-Online (http://www.eve-online.com).

Nobody is using Ruby for any 3D video games as far as I am aware but in case you encounter one feel free to drop me a line to let me know.

Ruby code can be made to run faster just by removing the comments from heavily commented Ruby code.

Maybe I am not a Ruby-person since I am aware of how wasteful the Ruby language is in real terms.

On the other hand.

Python simply rocks !

You have both the Ruby code and the Python code - make-up your own mind.

BTW - If you can find a faster way to write the Ruby code to make it run faster than Python then by all means drop me a line.


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

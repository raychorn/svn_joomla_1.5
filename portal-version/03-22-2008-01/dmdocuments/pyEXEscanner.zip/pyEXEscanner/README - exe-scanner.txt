exe-scanner will scan your hard drive (C:) and collect-up executables.

Why bother to write a program like this anyway ?

While I was working at BigFix, Inc. I was on a development team that was asked to design a system for scanning for executables.  BigFix produces enterprise-level software to manage thousands (up to 200,000) computer end-points within large enterprises.  BigFix wanted to create a way to inventory all those end-points for the lists of executable program one might find installed on each end-point.  The system BigFix chose to use was coded using C++ but I thought it might be interesting to do this with Python 2.5.1 and so the rest is history.  The BigFix solution was to scan for every single little executable whether DLL or EXE but I thought this was silly so I limited my solution to only meaningful executables excluding the silly DLLs and such.

Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

DELETE FROM `#__plugins` WHERE element = 'smartsef';
DROP TABLE `#__smartsef_urls`;
DROP TABLE `#__smartsef_router_setting`;
DROP TABLE `#__smartsef_plugins`;
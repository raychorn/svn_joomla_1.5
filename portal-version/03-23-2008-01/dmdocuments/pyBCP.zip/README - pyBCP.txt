pyBCP performs the same function as the Microsoft BCP Utility with some minor modifications related to scale.

pyBCP was designed to determine if Python could be used to craft a BCP utility capable of handling far more data faster than the Microsoft BCP utility program.

Say What ?

While I was employed at BigFix I was part of a development team that was asked to develop an ETL Process using Ruby.

Huh ?

Yes, you heard me right.

I said somebody, who shall remain nameless for obvious reasons, actually wanted to code an ETL Process using the Ruby Language.

I'll let that thought sink-in for a while.

*short pause*

Imagine for a moment we have a 5 GB database.

Now imagine this is a really small database that contains data from only 80,000 computer end-points.

Now imagine you expect a typical database to contain data for 200,000 computer end-points at a time.  This means a typical database will be more like 20 GB than 5 GB.

Now imagine you have a team of 3 programmers working furiously to code an ETL Process using Ruby and they spent 6 weeks to do it.  They just burned 18 man-weeks to do a what-if analysis on whether or not the Ruby Language can be used to code an ETL Process.

Now imagine this Ruby ETL Process required something like 16 hours to execute against this small 5 GB database.

Now imagine this team of 3 energetic, if not inexperienced, developers realized after spending 18 man-weeks on this assignment to build an ETL Process just learned Ruby might not have been the best choice when it comes to building an efficient ETL Process.

Now imagine I wanted to use the Python Language to code this ETL Process.

Ruby runs no faster than 30x slower than Python even on a really good day using heavily optimized Ruby code (no fair coding C++ extensions for Ruby just to make Ruby run faster either).

Python has a very nice JIT (Just In Time) Compiler known as Psyco that works really well and can achieve performance boosts no less than 2x but more typically around 15x to 20x faster than out of the box Python code assuming one tends to use coding constructs Pysco knows how to optimize.

pyBCP was designed to handle larger datasets than the Microsoft BCP utility.

Enjoy pyBCP for what it is.

Enjoy knowing the Ruby Language cannot be used to code an ETL Process if the goal is to (1) complete the coding task in less than 18 man-weeks and (2) achieve an efficient process that executes fast enough to be usable in real terms.

Some Ruby people like to turn their noses down at Python but bear in mind this 3-man development team had more than enough time (18 man-weeks) to develop their Ruby-powered ETL Process which means we cannot fault the developers since they had more than enough time to complete their task.

The #1 challenge for this 3-man development team was how to make their system for handling CSV (Comma Delimited Values) run fast enough to allow their Ruby-powered ETL Process run fast enough.

As we all know, all it takes to parse your run-of-the-mill CSV data is some ability to split on a silly (",") comma for crying out-loud.  Python handles this with ease using a simple expression such as "foo = csv.split(',')" to split apart the CSV fields and "','.join(foo)" to re-combine the split-out CSV fields back into the original data stream.

For whatever reason, this 3-man wonder-team at BigFix had to actually find a Ruby GEM called "FasterCSV" because apparently Ruby is just not able to parse CSV data fast enough without having to resort to using a C++ coded extension of some kind.

Look, the bottom line is this... If you just want to have fun writing code without thinking about the performance then by all means use Ruby.  But if you want to get some serious work done with some serious data then give some serious thought about using Python and Psyco.  Some companies might have 18 man-weeks to waste on this sort of thing but I know for a fact that BigFix did not because they had to down-size a bunch of people just to compensate for this type of needless tom-foolery.


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

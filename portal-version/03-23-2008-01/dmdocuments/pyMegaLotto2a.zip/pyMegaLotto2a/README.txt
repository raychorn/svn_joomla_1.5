Two methods are supplied to pick random number sequences.

See also the Package "pyMegaLotto 1.0" for the background for this version.

This version performs one additional level of analysis that uses a "period" that is represented as an integer. A period of 100 tells the program to gather 100 picks and then use those picks to seed the engine that picks based on the history of picks.

This might be useful in case there is any validity in the notion that future picks are based on past winning picks.  If we pick a bunch of possible picks and then use those picks to generate one single pick we might refine the method that attempts to pick winning numbers based on the history of picks.

The next verison in this series will attempt to weigh the validity of each of the methods presented for picking winning Lotto numbers to see how many iterations are required to properly pick a set of numbers that has been known to be a winning sequence.

Disclaimer: The author of this program makes no warranty as to the ability of this program to actually choose winning Lotto numbers however this program is capable of choosing winning lotto numbers.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose.

You may not redistribute this package without prior written permission from the author.

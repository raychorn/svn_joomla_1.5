# (c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.
# This software may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the
# end-goal or end-product is of a non-commercial purpose.
# The person(s) who win any lotto or other gambling or wagering system using this program must agree to give 20% of their winnings to the author of
# this program as specified by the copyright notice given above.

from random import choice

numbers = xrange(1,25)
megas = xrange(1,15)

num_numbers = 5
num_total = num_numbers+1

choices = []

for n in xrange(0,num_numbers):
	aChoice = choice(list(set(numbers).difference(set(choices))))
	print '(%s)' % aChoice
	choices.append(aChoice)

for n in xrange(0,num_total-num_numbers):
	aChoice = choice(megas)
	print 'Mega=(%s)' % aChoice

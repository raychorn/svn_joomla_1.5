# (c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.
# This software may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the
# end-goal or end-product is of a non-commercial purpose.

# The person(s) who win any lotto or other gambling or wagering system using this program must agree to give 20% of their winnings to the author of
# this program as specified by the copyright notice given above.

# This version uses real data from the California Mega Lotto Drawing History from 06-24-2005 thru 02-15-2008 to determine which numbers
# have been picked in terms of which numbers may possibly be picked next.

#
# This could be easily made into a professional-looking Lotto Picks Generator by using a frequency distribution technique that populates
# the list of numbers to pick from based on the number of times numbers had been picked in the past per number slot.
#
import os
import sys
from random import choice
from random import shuffle

def listify(d,key,value):
    bucket = value
    if ( (isinstance(d,dict)) and (d.has_key(key)) ):
	bucket = d[key]
	if (not isinstance(bucket,list)):
	    bucket = [bucket]
	bucket.append(value)
    return bucket

def loadWinningNumbers(fname):
    d = {}
    f = {}
    m = {}
    fx = {}
    mx = {}
    c1 = []
    c2 = []
    if (os.path.exists(fname)):
	fHand = open(fname,'r')
	for l in fHand.readlines():
	    toks = l.split()
	    d[toks[0]] = toks
	    for n in toks[2:-1]:
		_n = int(n)
		f[_n] = listify(f,_n,_n)
	    _n = int(toks[-1])
	    m[_n] = listify(f,_n,_n)
	fHand.close()
	for k,v in f.iteritems():
	    _n = len(v)
	    fx[k] = _n
	    for n in xrange(0,_n):
		c1.append(k)
	for k,v in m.iteritems():
	    _n = len(v)
	    mx[k] = _n
	    for n in xrange(0,_n):
		c2.append(k)
	shuffle(c1)
	shuffle(c2)
    return (d,f,m,fx,mx,c1,c2)

def reshuffleWinningNumbers(db,choices):
    d, f, m, fx, mx, c1, c2 = db
    fx = {}
    c1 = []
    for k,v in f.iteritems():
	if (k not in choices):
	    _n = len(v)
	    fx[k] = _n
	    for n in xrange(0,_n):
		c1.append(k)
    shuffle(c1)
    return (d,f,m,fx,mx,c1,c2)

numbers = xrange(1,56)
megas = xrange(1,46)

num_numbers = 5
num_total = num_numbers+1

choices = []

_db = loadWinningNumbers('MegaMillions.txt')

print 'Purely Random Selection:'
for n in xrange(0,num_numbers):
    aChoice = choice(list(set(numbers).difference(set(choices))))
    choices.append(aChoice)
choices.sort()
for c in choices:
    print '(%s)' % c

for n in xrange(0,num_total-num_numbers):
    aChoice = choice(megas)
    print 'Mega=(%s)' % aChoice
print '='*30
print

choices = []
numbers = _db[-2]
megas = _db[-1]

print 'Weighted Random Selection:'
for n in xrange(0,num_numbers):
    aChoice = choice(list(set(numbers).difference(set(choices))))
    choices.append(aChoice)
    _db = reshuffleWinningNumbers(_db,choices)
choices.sort()
for c in choices:
    print '(%s)' % c

for n in xrange(0,num_total-num_numbers):
    aChoice = choice(megas)
    print 'Mega=(%s)' % aChoice
print '='*30
print

pyRubyNightlyBuild - Python based Nightly Build System for Ruby Apps.

Once upon a time while I was working at BigFix there was this Ruby development dream-team composed of 3 top-tier software engineers with stunning college degrees and they were asked to cough-up a Nightly Build for their premier Ruby App.  

I also heard this call for a Nightly Build System and I completed mine in 3 days.  
They completed theirs in 30 days but they had to call on the talents of the Senior Build Engineer who employed the talents of a commercial product anyone could have used.  

This is not to say the folks at BigFix are not technically savvy -- they were able to make a Nightly Build system for their Ruby App and who cares about the 30 days anyway.  

Let's just ignore the fact that one focused person will always be able to out-perform any number of semi-focused people for relatively simple tasks.  

"How many people does it take at BigFix to change a light-bulb ?"   Which light bulb were we supposed to change ?  Let's change that one over there.  No, wait, let's change a different light bulb.  Half-way through changing the light bulb we can just change our minds and change a different one anyway.

Let's keep in mind the fact that the BigFix way of doing things is to figure-out the optimal method and then ignore it in favor of the least optimal method for doing whatever it is they wish to do.  But don't take my word for it.  Take their word for it.  Take a really close look at their product-line to see how BigFix does things.


And the merits of using pyRubyNightlyBuild would be what exactly ?

pyRubyNightlyBuild captures all the files from a Ruby installation - all 25,000 some odd files, including all those GEMs and that Mongel server code for that single-threaded web server so many Ruby on Rails people think is multi-threaded except it ain't.

pyRubyNightlyBuild also automatically adjusts all those batch files (you know the ones that have .bat as their last names) to allow Ruby to be relocated to a new folder; you know, just in case someone actually wanted to use Ruby once it has been installed -- this is the reason people make a Nightly Build, so they can install the silly thing the next day and use it.

Let's talk about ease of use for a moment.

pyRubyNightlyBuild is easy to use because it is simple.  

pyRubyNightlyBuild is based on the ZIP file format rather than MSI.  

MSI could have been used except MSI installers like the one built into the Windows OS tend to bog-down a bit when faced with 25,000 files or thereabouts.

pyRubyNightlyBuild does not have a GUI.  Oops, did I forget to make a GUI for this silly thing ?!?

pyRubyNightlyBuild is simple and straight-forward.  Just launch the installer and the rest happens automatically including the removal of the previous build.

pyRubyNightlyBuild was easy to build.  Took only 3 man-days versus the 30 days 4 people consumed as they collaborated to create their MSI based Nightly Build.

pyRubyNightlyBuild is extensible !

pyRubyNightlyBuild could be made to strip-out GEMs that are not required for any specific purpose.

pyRubyNightlyBuild could be made to add-in GEMs that may be required for a specific purpose.

pyRubyNightlyBuild could be made to perform a battery of automated tests to make sure the installed App is fully functional as part of the installation process.

Your typical MSI based installation builder does not provide the extensibility of pyRubyNightlyBuild.

pyRubyNightlyBuild is powerful !

pyRubyNightlyBuild uses Python for all the heavy-lifting and Ruby for all the light work during the installation process.

Let's face it folks, Python is just a better language when it comes to coding any iterative process such as collecting-up file names and putting them into a ZIP file.

Ruby is well suited to handling routine non-performance related tasks such as performing an UnZIP process.

The Python code could have been compiled into a free-standing EXE but for the purposes of this version it is assumed the Python runtime is installed on the computer one wishes to use to automate the Build Process.

Ruby need not be installed on the target computer where the Nightly Build is installed because the entire Nightly Build is "compiled: into a free-standing Ruby-based EXE (I kid you not!)


Enjoy pyRubyNightlyBuild !


Disclaimer: The author of this program makes no warranty as to the suitability of this program for any purpose whatsoever nor is there any warranty to as to whether this program will be able to properly handle your specific needs.

(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.

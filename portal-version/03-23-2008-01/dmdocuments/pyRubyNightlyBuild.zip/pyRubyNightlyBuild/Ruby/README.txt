dss.rb is the program that builds the EXE that is used to perform the installation process.

Why was it called dss.rb ?

Well, if you want it to be called something else then take some time and rename it and all references to it and then life will be happier for you.

It is left up to those who wish to use this code to find the specific GEMs that are required to make all this magic happen.

You can always contact the author(s) of this code to get some support, in case you are not the savvy Ruby coder we all hope you are.  

Really don't be afraid to ask for help, isn't this what everyone tells you ?!?  

Well maybe they weren't singling you out of the crowd for any specific reason.  

I mean, it's not like you can't figure it out if you need to, right ?!?  

Now don't feel bad.  

We all need some help once in a while, right ?!?

There aren't that many GEMs to search through -- you'll find the right ones, I'm sure.
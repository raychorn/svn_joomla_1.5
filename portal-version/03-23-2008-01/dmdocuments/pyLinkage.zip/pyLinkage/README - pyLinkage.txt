pyLinkage Linked Lists of all things - such a wastefull thing to do with any modern (post 1988 A.D.) language.

Once upon a time I was asked to code a programmer's test as part of an extrance exam for a start-up that shall remain nameless for the purpose of this little project.  

On this programmer's test were a series of questions dealing with linked lists.

Linked lists ?  Are you nuts ?

Do you have any idea on god's green earth just how grossly inefficient Linked Lists have become since the beginning of time since Python came on the scene with built-in List handling functions ?!?

Okay, way back in the dark ages before Python existed we all had to code linked lists using the C language - this predates the existance of C++ by several years.

The C language knew nothing about the Array other than some idea that data objects (called Struct's) could be linked together to form chains of data.

Today we have a number of languages to choose from that all know all about how to string data together to form chains they call an "Array".

An Array of data is a list of data where one data object follows another.  This is exactly what a linked list seeks to do - link one data element to another to form a list of data elements.

As it turns out, when Python is used to code One-Way Linked lists the resulting code runs about 1200 times slower than if built-in Python Lists had been used.

Now then, is there any benefit to using Linked Lists now that we have entered the 21st Century ?

Well, let's see.  Python can handle about 3 GB of RAM per 32 bit process depending on how Windows is setup.  If one needs to handle more than 3 GB at a time one can easily use a 64-bit version of Python and while the resulting code won't run faster than had 32 bits been used at-least one can deal with a whole lot more RAM at a time.

Is there ever a requirement to use Linked Lists anymore ?

Probably not.

Even if your goal was to use C++ due to the obvious performance boost of doing so over other higher-level languages one would surely want to wrapper their C++ code using something like Python due to the obvious advantages inherent in using Python to wrapper C++ code.  Bring Psyco into the mix and one finds there is much less of a reason to write low-level C++ code than might otherwise been the case.  Make heavy use of List Comprehensions and the other techniques Psyco knows how to optimize and one probably never thinks about using C++ due to the time required to code C++ versus the time saved in coding Python.

If one needs to manipulate a chunk of data as detached records one can more easily use a Python dictionary rather than a List.

If one needs to make one's dictionary persistent one can easily use pyOODB which brings together the benefits of dictionaries with the usefulness of making objects persistent and the efficiency of using List Comprehensions.

Let's face it folks, Linked Lists are dead !

Linked Lists execute 1200 times slower than Python's built-in sorting function when one wishes to sort integers.

If you want to sort strings then use the pyOODB or some variant of a built-in sorting technique available to Python.

Now maybe you've got some really super-intense reason to use Linked Lists coded using C++ or even Assembly Language but then you might have some functions precoded you intend to use rather than code all that stuff yourself.  Weight the time required to code optimized Linked List functions using C++ versus the time saved in using Python's List handling functions and maybe, just maybe it is faster and cheaper to use Python and be done with it.

For my money, I would use Python and Pysco and maybe once in a while Boost.Python to code some C++ for those really hairy and intense times when Python is just not fast enough but I would surely not use Linked Lists under any circumstances unless I absolutely had no other alternative and those times don't happen all that often.



(c). Copyright 2007-2008, Ray C Horn (raychorn@hotmail.com) and Hierarchical Applications Limited, Inc., All Rights Reserved.

This software package and all contents contained herein may not be used for any commercial purpose whatsoever however it may be used for educational purposes so long as the end-goal or end-product is of a non-commercial purpose and there was never any intent to use this package to generate any income of any kind.

You may not redistribute this package without prior written permission from the author.
